from datetime import datetime
import platform
import os

def display_greeting():
    """Display a greeting message with ASCII art when SIEM starts."""
    
    # ASCII art for SIEM
    ascii_art = """
  _____   _____   ______   __    __
 / ____| |_   _| |  ____| |  \\/  |
| (___     | |   | |__    | \\  / |
 \\___ \\    | |   |  __|   | |\\/| |
 ____) |  _| |_  | |____  | |  | |
|_____/  |_____| |______| |_|  |_|
                                    
 Security Information & Event Management
 Network Traffic Monitoring System
 """
    
    # Get system information
    os_info = platform.system() + " " + platform.release()
    hostname = platform.node()
    
    # Clear screen first
    os.system('cls' if os.name == 'nt' else 'clear')
    
    print("\033[1;36m" + ascii_art + "\033[0m")  # Cyan color for ASCII art
    print("\033[1;33m" + "=" * 50 + "\033[0m")   # Yellow divider
    print("\033[1;32m" + f"Started at: {datetime.now()}" + "\033[0m")
    print("\033[1;32m" + f"System: {os_info}" + "\033[0m")
    print("\033[1;32m" + f"Hostname: {hostname}" + "\033[0m")
    print("\033[1;32m" + "Developed by: Octopyder Services" + "\033[0m")
    print("\033[1;33m" + "=" * 50 + "\033[0m")   # Yellow divider
    
    print("\n\033[1;37m[INFO]\033[0m Network traffic monitoring will be active in the background")
    print("\033[1;37m[INFO]\033[0m All logs will be saved in /var/log/siem_logs directory")
    print()
