#!/usr/bin/env python3
import os
import hashlib
import json
import urllib.request
import urllib.error
import subprocess
import argparse
import sys

# Path to the log file
LOG_FILE = "/var/log/siem_logs/network_logs.json"

# File to store the last sent checksum (hidden file in home directory)
CHECKSUM_FILE = os.path.expanduser("~/.siem_last_sent_checksum")

def setup_log_access():
    """Set up permissions for log directory access for regular users."""
    log_dir = "/var/log/siem_logs"
    try:
        # Create directory if it doesn't exist
        if not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
            print(f"Created log directory: {log_dir}")
        
        # On Windows, we don't need special permissions
        if sys.platform == 'win32':
            print(f"Windows platform detected, no special permissions needed for: {log_dir}")
        else:
            # For Linux/Mac, set permissions
            try:
                subprocess.run(["chmod", "755", log_dir], check=True)
                current_user = os.environ.get('USER', os.environ.get('USERNAME', 'unknown'))
                subprocess.run(["chown", f"{current_user}:", log_dir], check=True)
                print(f"Set permissions for log directory: {log_dir}")
            except Exception as e:
                print(f"Warning: Could not set permissions (not running as root?): {e}")
        
        print(f"Successfully configured log directory: {log_dir}")
        return log_dir
    except Exception as e:
        print(f"Failed to configure log directory: {str(e)}")
        return log_dir  # Return the directory even if setup failed

def calculate_checksum(file_path):
    """Calculate MD5 checksum of the file's content."""
    md5 = hashlib.md5()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                md5.update(chunk)
        return md5.hexdigest()
    except Exception as e:
        print(f"Error calculating checksum: {e}")
        return None

def has_been_sent(current_checksum):
    """Check if the current checksum matches the stored checksum."""
    if os.path.exists(CHECKSUM_FILE):
        try:
            with open(CHECKSUM_FILE, "r") as f:
                last_checksum = f.read().strip()
            return last_checksum == current_checksum
        except Exception as e:
            print(f"Error reading checksum file: {e}")
    return False

def store_checksum(checksum):
    """Store the checksum to the marker file."""
    try:
        with open(CHECKSUM_FILE, "w") as f:
            f.write(checksum)
    except Exception as e:
        print(f"Error storing checksum: {e}")

def send_logs(api_url, api_key, json_data):
    """Send the JSON log data to the API via HTTP POST."""
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key
    }
    data_bytes = json_data.encode("utf-8")

    print("\n--- DEBUG: Sending this JSON ---")
    print(json_data[:500] + "\n... (truncated)")  # Print the first 500 chars
    print("--- END DEBUG ---\n")

    req = urllib.request.Request(api_url, data=data_bytes, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as response:
            resp_data = response.read().decode("utf-8")
            print(f"Response from API: {resp_data}")
            return True
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} - {e.reason}")
        error_body = e.read().decode("utf-8")
        print("API Error Response:", error_body)
    except urllib.error.URLError as e:
        print(f"URL Error: {e.reason}")
    except Exception as e:
        print(f"Error sending logs: {e}")
    return False

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Send SIEM logs to an API endpoint')
    parser.add_argument('--endpoint', dest='api_url', help='API endpoint URL')
    parser.add_argument('--key', dest='api_key', help='API key for authentication')
    args = parser.parse_args()
    
    # Get API URL and API key from args or user input
    api_url = args.api_url if args.api_url else input("Enter the API URL (e.g., http://localhost:3000/api/logs): ").strip()
    api_key = args.api_key if args.api_key else input("Enter the API key: ").strip()

    # Make sure the log directory exists
    setup_log_access()
    
    # Check if JSON file exists
    if not os.path.exists(LOG_FILE):
        print(f"Error: Log file not found at {LOG_FILE}")
        print("Please make sure the SIEM system is running and generating logs.")
        return False

    # Calculate current file checksum
    current_checksum = calculate_checksum(LOG_FILE)
    if current_checksum is None:
        print("Cannot calculate checksum. Exiting.")
        return False

    # Check if logs have already been sent
    if has_been_sent(current_checksum):
        print("Logs have already been sent. No action taken.")
        return True

    # Read the JSON file in full
    try:
        with open(LOG_FILE, "r") as f:
            json_content = f.read()
    except Exception as e:
        print(f"Error reading log file: {e}")
        return False

    # Optionally, verify that it's valid JSON
    try:
        parsed = json.loads(json_content)
        # Re-dump to preserve the full format in a consistent manner
        json_data = json.dumps(parsed, indent=2)
    except Exception as e:
        print(f"Error parsing JSON: {e}")
        return False

    # Send logs to the API
    if send_logs(api_url, api_key, json_data):
        print("Logs sent successfully.")
        store_checksum(current_checksum)
        return True
    else:
        print("Failed to send logs.")
        return False

if __name__ == "__main__":
    sys.exit(0 if main() else 1) 